import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, pgEnum, index, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enums
export const userRoleEnum = pgEnum("user_role", [
  "super_admin",
  "tenant_admin",
  "support_agent",
  "customer",
]);

export const ticketCategoryEnum = pgEnum("ticket_category", [
  "Support",
  "Bug",
  "Feature",
]);

export const ticketStatusEnum = pgEnum("ticket_status", [
  "Open",
  "In Progress",
  "Closed",
]);

export const ticketPriorityEnum = pgEnum("ticket_priority", [
  "Low",
  "Medium",
  "High",
]);

export const customerStatusEnum = pgEnum("customer_status", [
  "Active",
  "Inactive",
]);

// Tenants table
export const tenants = pgTable("tenants", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: varchar("name", { length: 150 }).notNull(),
  contactEmail: varchar("contact_email", { length: 150 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Users table - integrated with Replit Auth + multi-tenant support
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email", { length: 150 }).unique(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default("customer"),
  tenantId: integer("tenant_id").references(() => tenants.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Customers table
export const customers = pgTable("customers", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 150 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  company: varchar("company", { length: 150 }),
  status: customerStatusEnum("status").notNull().default("Active"),
  tenantId: integer("tenant_id").notNull().references(() => tenants.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Tickets table
export const tickets = pgTable("tickets", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  ticketNumber: varchar("ticket_number", { length: 20 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: ticketCategoryEnum("category").notNull(),
  status: ticketStatusEnum("status").notNull().default("Open"),
  priority: ticketPriorityEnum("priority").notNull().default("Medium"),
  createdById: varchar("created_by_id").notNull().references(() => users.id),
  assignedToId: varchar("assigned_to_id").references(() => users.id),
  customerId: integer("customer_id").references(() => customers.id),
  tenantId: integer("tenant_id").notNull().references(() => tenants.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Messages table - for chat/ticket communication
export const messages = pgTable("messages", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  content: text("content").notNull(),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  ticketId: integer("ticket_id").references(() => tickets.id),
  customerId: integer("customer_id").references(() => customers.id),
  tenantId: integer("tenant_id").notNull().references(() => tenants.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertTenantSchema = createInsertSchema(tenants, {
  name: z.string().min(1),
  contactEmail: z.string().email(),
}).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users, {
  email: z.string().email().optional(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
}).omit({
  createdAt: true,
  updatedAt: true,
});

export const upsertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
});

export const insertCustomerSchema = createInsertSchema(customers, {
  name: z.string().min(1),
  email: z.string().email(),
}).omit({
  id: true,
  createdAt: true,
});

export const insertTicketSchema = createInsertSchema(tickets, {
  title: z.string().min(1),
  description: z.string().min(1),
}).omit({
  id: true,
  ticketNumber: true,
  createdAt: true,
  updatedAt: true,
});

export const updateCustomerSchema = z.object({
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  company: z.string().optional(),
  status: z.enum(["Active", "Inactive"]).optional(),
});

export const updateTicketSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().min(1).optional(),
  category: z.enum(["Support", "Bug", "Feature"]).optional(),
  status: z.enum(["Open", "In Progress", "Closed"]).optional(),
  priority: z.enum(["Low", "Medium", "High"]).optional(),
  customerId: z.number().optional(),
});

export const insertMessageSchema = createInsertSchema(messages, {
  content: z.string().min(1),
}).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertTenant = z.infer<typeof insertTenantSchema>;
export type Tenant = typeof tenants.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
