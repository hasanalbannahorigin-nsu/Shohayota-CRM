# Design Guidelines: Multi-Tenant CRM System

## Design Approach
**Selected Approach**: Design System - Material Design + Linear-inspired modern CRM patterns

**Justification**: This is a utility-focused, information-dense productivity application where efficiency, data clarity, and consistent patterns are paramount. Drawing from Material Design for robust component guidelines and Linear for modern issue tracking aesthetics.

**Core Principles**:
- Data clarity over decoration
- Consistent patterns for cognitive ease
- Responsive layouts that adapt gracefully
- Clear visual hierarchy for role-based interfaces
- Efficient information density

---

## Typography

**Font Families**:
- Primary: Inter (Google Fonts) - body text, UI elements
- Secondary: JetBrains Mono (Google Fonts) - ticket IDs, technical data

**Hierarchy**:
- Page Headers: text-3xl font-semibold (30px)
- Section Headers: text-xl font-semibold (20px)
- Card/Module Headers: text-lg font-medium (18px)
- Body Text: text-base font-normal (16px)
- Secondary/Meta: text-sm text-gray-600 (14px)
- Labels: text-xs font-medium uppercase tracking-wide (12px)

---

## Layout System

**Spacing Units**: Use Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4, p-6
- Section gaps: gap-6, gap-8
- Card spacing: p-6
- Form field gaps: space-y-4
- Grid gaps: gap-4, gap-6

**Container Strategy**:
- Dashboard main: max-w-7xl mx-auto px-4
- Forms/modals: max-w-2xl
- Sidebar: fixed w-64
- Content area: flex-1 with proper margins

---

## Component Library

### Navigation
**Sidebar Navigation** (Primary):
- Fixed left sidebar (w-64) with tenant switcher at top
- Collapsible on mobile to hamburger menu
- Menu items with icons (Heroicons) + labels
- Active state: subtle background highlight
- Grouped sections: Dashboard, Customers, Tickets, Chat, Users, Analytics

**Top Bar**:
- User profile menu (right)
- Global search bar (center-left, w-96)
- Notification bell icon
- Breadcrumb navigation below on content pages

### Data Display
**Tables**:
- Striped rows for readability (alternate subtle background)
- Sticky headers on scroll
- Row actions on hover (right side)
- Sortable columns with indicator icons
- Compact row height with adequate padding (py-3)
- Pagination at bottom: showing "1-20 of 156 results"

**Cards**:
- Ticket cards: rounded-lg border p-6
- Status badge (top-right): rounded-full px-3 py-1 text-xs font-medium
- Priority indicator: colored vertical bar (left edge, w-1)
- Metadata row: flex justify-between items-center mt-4

**Stats Widgets**:
- Grid layout: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6
- Each widget: rounded-lg border p-6
- Large number: text-3xl font-bold
- Label below: text-sm
- Trend indicator: small icon + percentage

### Forms
**Input Fields**:
- Full-width with labels above: block mb-2 text-sm font-medium
- Input styling: rounded-md border px-4 py-2.5
- Focus state: ring-2 ring-offset-2
- Helper text below: text-xs mt-1
- Required fields: asterisk in label

**Form Layouts**:
- Single column for simplicity
- Multi-step forms: progress indicator at top (stepper)
- Action buttons at bottom-right: flex justify-end gap-3

**Dropdowns/Selects**:
- Custom styled selects with chevron icon
- Multi-select with tags display
- Searchable dropdowns for large datasets

### Chat Interface
**Chat Container**:
- Two-column when space allows: ticket list (left 1/3) + conversation (right 2/3)
- Message bubbles: max-w-lg rounded-2xl px-4 py-2
- Agent messages: align-left
- Customer messages: align-right
- Timestamp: text-xs below each message
- Input bar: sticky bottom with rounded input + send button

### Modals/Overlays
**Modal Structure**:
- Overlay: backdrop blur with semi-transparency
- Modal: max-w-2xl rounded-xl p-8
- Header with title + close button (top-right)
- Scrollable content area
- Action buttons in footer: right-aligned

**Dropdowns/Popovers**:
- Rounded-lg shadow-lg border
- Padding: p-2
- Menu items: rounded-md px-3 py-2 hover state

### Buttons
**Primary Actions**: rounded-md px-6 py-2.5 font-medium
**Secondary**: border variant of primary
**Tertiary/Ghost**: text-only with hover state
**Icon Buttons**: p-2 rounded-md, icon centered
**Button Groups**: adjacent buttons with shared borders

---

## Page-Specific Layouts

### Dashboard (Landing)
- Stats widget grid at top (4 columns)
- Two-column below: Recent Tickets (left) + Activity Feed (right)
- Each section in rounded-lg border cards

### Ticket List/Management
- Filter bar at top: dropdowns for status, priority, assignee
- Table view with sortable columns
- Bulk action toolbar appears when rows selected

### Customer Profile
- Header section: customer name, contact info, account stats
- Tabbed interface: Overview, Tickets, Communication History
- Activity timeline in sidebar

### Tenant Management (Super Admin)
- Card grid of tenants (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Each card shows tenant name, user count, active tickets
- "Add Tenant" button (top-right)

---

## Responsive Behavior

**Mobile Adaptations**:
- Sidebar collapses to overlay menu
- Tables switch to stacked cards
- Multi-column layouts become single column
- Stats widgets: 2 columns max on tablet, 1 on mobile
- Chat: full-screen conversation view, back to list

**Breakpoints**: sm: 640px, md: 768px, lg: 1024px, xl: 1280px

---

## Icons
**Library**: Heroicons (via CDN)
**Usage**:
- Navigation menu items: outline variant, w-5 h-5
- Buttons: w-4 h-4 inline with text
- Status indicators: solid variant, w-4 h-4
- Table actions: outline, w-5 h-5

---

## Accessibility
- All interactive elements keyboard navigable
- Focus indicators on all form fields and buttons
- ARIA labels for icon-only buttons
- Color not sole indicator of status (use icons + text)
- Minimum touch target: 44px × 44px

---

## Images
**Usage**: Minimal in this utility application
- Empty states: Simple illustrations (undraw.co style) for "No tickets yet", "No customers"
- User avatars: circular, w-10 h-10 default size
- Tenant logos: small square in tenant switcher
- No hero images - this is a dashboard application