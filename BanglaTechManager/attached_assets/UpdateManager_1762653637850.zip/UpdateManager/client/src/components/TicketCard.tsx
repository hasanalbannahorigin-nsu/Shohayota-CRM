import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Clock } from "lucide-react";

interface TicketCardProps {
  id: string;
  title: string;
  description: string;
  category: "Support" | "Bug" | "Feature";
  status: "Open" | "In Progress" | "Closed";
  priority: "Low" | "Medium" | "High";
  assignee?: {
    name: string;
    initials: string;
  };
  createdAt: string;
  testId?: string;
}

const categoryColors = {
  Support: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  Bug: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  Feature: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
};

const statusColors = {
  Open: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  Closed: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
};

const priorityColors = {
  Low: "bg-gray-200 dark:bg-gray-700",
  Medium: "bg-yellow-400 dark:bg-yellow-600",
  High: "bg-red-500 dark:bg-red-600",
};

export function TicketCard({
  id,
  title,
  description,
  category,
  status,
  priority,
  assignee,
  createdAt,
  testId,
}: TicketCardProps) {
  return (
    <Card
      className="p-6 hover-elevate cursor-pointer relative overflow-hidden"
      data-testid={testId}
    >
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${priorityColors[priority]}`} />
      <div className="flex items-start justify-between gap-4 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-mono text-muted-foreground" data-testid={`${testId}-id`}>
              #{id}
            </span>
            <Badge className={categoryColors[category]} data-testid={`${testId}-category`}>
              {category}
            </Badge>
          </div>
          <h3 className="font-semibold text-lg mb-1 truncate" data-testid={`${testId}-title`}>
            {title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`${testId}-description`}>
            {description}
          </p>
        </div>
        <Badge className={statusColors[status]} data-testid={`${testId}-status`}>
          {status}
        </Badge>
      </div>
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span data-testid={`${testId}-created`}>{createdAt}</span>
        </div>
        {assignee && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Assigned to</span>
            <Avatar className="h-6 w-6">
              <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                {assignee.initials}
              </AvatarFallback>
            </Avatar>
          </div>
        )}
      </div>
    </Card>
  );
}
