import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Send } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Message {
  id: string;
  sender: "agent" | "customer";
  content: string;
  timestamp: string;
  senderName: string;
}

interface ChatInterfaceProps {
  messages: Message[];
  customerName: string;
  testId?: string;
}

export function ChatInterface({ messages, customerName, testId }: ChatInterfaceProps) {
  const [newMessage, setNewMessage] = useState("");

  const handleSend = () => {
    if (newMessage.trim()) {
      console.log("Sending message:", newMessage);
      setNewMessage("");
    }
  };

  return (
    <Card className="flex flex-col h-[600px]" data-testid={testId}>
      <div className="border-b p-4">
        <h3 className="font-semibold text-lg">Chat with {customerName}</h3>
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.sender === "agent" ? "" : "flex-row-reverse"}`}
              data-testid={`message-${message.id}`}
            >
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {message.senderName.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div
                className={`flex flex-col gap-1 max-w-lg ${message.sender === "agent" ? "" : "items-end"}`}
              >
                <div
                  className={`rounded-2xl px-4 py-2 ${
                    message.sender === "agent"
                      ? "bg-muted"
                      : "bg-primary text-primary-foreground"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
                <span className="text-xs text-muted-foreground">{message.timestamp}</span>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
      <div className="border-t p-4">
        <div className="flex gap-2">
          <Input
            placeholder="Type your message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
            data-testid="input-chat-message"
          />
          <Button onClick={handleSend} data-testid="button-send-message">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
