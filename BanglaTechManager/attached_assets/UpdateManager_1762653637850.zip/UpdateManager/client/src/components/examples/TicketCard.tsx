import { TicketCard } from '../TicketCard'

export default function TicketCardExample() {
  return (
    <div className="p-8 max-w-2xl">
      <TicketCard
        id="TKT-1234"
        title="Login page not loading"
        description="Users are experiencing issues when trying to access the login page. The page appears to be stuck on a loading screen."
        category="Bug"
        status="In Progress"
        priority="High"
        assignee={{ name: "Sarah Johnson", initials: "SJ" }}
        createdAt="2 hours ago"
        testId="ticket-1234"
      />
    </div>
  )
}
