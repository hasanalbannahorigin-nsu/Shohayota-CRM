import { useState } from 'react'
import { CreateTicketModal } from '../CreateTicketModal'
import { Button } from '@/components/ui/button'

export default function CreateTicketModalExample() {
  const [open, setOpen] = useState(false)

  return (
    <div className="p-8">
      <Button onClick={() => setOpen(true)}>Open Create Ticket Modal</Button>
      <CreateTicketModal open={open} onOpenChange={setOpen} testId="create-ticket-modal" />
    </div>
  )
}
