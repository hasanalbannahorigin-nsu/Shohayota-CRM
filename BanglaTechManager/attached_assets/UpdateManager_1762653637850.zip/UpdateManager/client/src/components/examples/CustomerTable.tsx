import { CustomerTable } from '../CustomerTable'

const mockCustomers = [
  {
    id: "1",
    name: "Alice Johnson",
    email: "alice@example.com",
    phone: "+1 234-567-8901",
    company: "Tech Solutions Inc",
    status: "Active" as const,
    ticketCount: 5,
  },
  {
    id: "2",
    name: "Bob Smith",
    email: "bob@example.com",
    phone: "+1 234-567-8902",
    company: "Digital Ventures",
    status: "Active" as const,
    ticketCount: 2,
  },
  {
    id: "3",
    name: "Carol Williams",
    email: "carol@example.com",
    phone: "+1 234-567-8903",
    company: "Innovation Labs",
    status: "Inactive" as const,
    ticketCount: 0,
  },
];

export default function CustomerTableExample() {
  return (
    <div className="p-8">
      <CustomerTable customers={mockCustomers} testId="customer-table" />
    </div>
  )
}
