import { UserMenu } from '../UserMenu'

export default function UserMenuExample() {
  return <UserMenu />
}
