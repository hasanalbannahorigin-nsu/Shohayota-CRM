import { ChatInterface } from '../ChatInterface'

const mockMessages = [
  {
    id: "1",
    sender: "customer" as const,
    content: "Hi, I'm having trouble logging into my account",
    timestamp: "10:30 AM",
    senderName: "Alice Johnson",
  },
  {
    id: "2",
    sender: "agent" as const,
    content: "Hello Alice! I'd be happy to help you with that. Can you tell me what error message you're seeing?",
    timestamp: "10:31 AM",
    senderName: "Support",
  },
  {
    id: "3",
    sender: "customer" as const,
    content: "It says 'Invalid credentials' but I'm sure my password is correct",
    timestamp: "10:32 AM",
    senderName: "Alice Johnson",
  },
  {
    id: "4",
    sender: "agent" as const,
    content: "Let me check your account. Have you recently changed your password?",
    timestamp: "10:33 AM",
    senderName: "Support",
  },
];

export default function ChatInterfaceExample() {
  return (
    <div className="p-8 max-w-4xl">
      <ChatInterface
        messages={mockMessages}
        customerName="Alice Johnson"
        testId="chat-interface"
      />
    </div>
  )
}
