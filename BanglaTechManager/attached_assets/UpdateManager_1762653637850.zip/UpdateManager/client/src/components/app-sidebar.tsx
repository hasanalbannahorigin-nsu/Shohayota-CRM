import {
  Building2,
  LayoutDashboard,
  Users,
  TicketIcon,
  MessageSquare,
  UserCog,
  BarChart3,
  ChevronDown,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const menuItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
    testId: "link-dashboard",
  },
  {
    title: "Customers",
    url: "/customers",
    icon: Users,
    testId: "link-customers",
  },
  {
    title: "Tickets",
    url: "/tickets",
    icon: TicketIcon,
    testId: "link-tickets",
  },
  {
    title: "Chat",
    url: "/chat",
    icon: MessageSquare,
    testId: "link-chat",
  },
  {
    title: "Users",
    url: "/users",
    icon: UserCog,
    testId: "link-users",
  },
  {
    title: "Analytics",
    url: "/analytics",
    icon: BarChart3,
    testId: "link-analytics",
  },
];

//todo: remove mock functionality
const mockTenants = [
  { id: "1", name: "Acme Corp", initials: "AC" },
  { id: "2", name: "TechStart Inc", initials: "TS" },
  { id: "3", name: "Global Solutions", initials: "GS" },
];

export function AppSidebar() {
  const [location] = useLocation();
  //todo: remove mock functionality
  const currentTenant = mockTenants[0];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="flex w-full items-center gap-3 rounded-md p-2 hover-elevate active-elevate-2"
              data-testid="button-tenant-switcher"
            >
              <Avatar className="h-9 w-9">
                <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
                  {currentTenant.initials}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 text-left">
                <div className="text-sm font-medium">{currentTenant.name}</div>
                <div className="text-xs text-muted-foreground">Switch tenant</div>
              </div>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="start">
            {mockTenants.map((tenant) => (
              <DropdownMenuItem
                key={tenant.id}
                data-testid={`tenant-option-${tenant.id}`}
              >
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                    {tenant.initials}
                  </AvatarFallback>
                </Avatar>
                {tenant.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={item.testId}
                  >
                    <Link href={item.url}>
                      <item.icon className="h-5 w-5" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
