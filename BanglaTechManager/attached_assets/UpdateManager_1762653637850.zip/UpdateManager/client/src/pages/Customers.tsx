import { useState } from "react";
import { CustomerTable } from "@/components/CustomerTable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search } from "lucide-react";

//todo: remove mock functionality
const mockCustomers = [
  {
    id: "1",
    name: "Alice Johnson",
    email: "alice@techsolutions.com",
    phone: "+1 234-567-8901",
    company: "Tech Solutions Inc",
    status: "Active" as const,
    ticketCount: 5,
  },
  {
    id: "2",
    name: "Bob Smith",
    email: "bob@digitalventures.com",
    phone: "+1 234-567-8902",
    company: "Digital Ventures",
    status: "Active" as const,
    ticketCount: 2,
  },
  {
    id: "3",
    name: "Carol Williams",
    email: "carol@innovationlabs.com",
    phone: "+1 234-567-8903",
    company: "Innovation Labs",
    status: "Inactive" as const,
    ticketCount: 0,
  },
  {
    id: "4",
    name: "David Brown",
    email: "david@startupco.com",
    phone: "+1 234-567-8904",
    company: "StartUp Co",
    status: "Active" as const,
    ticketCount: 8,
  },
  {
    id: "5",
    name: "Eva Martinez",
    email: "eva@cloudservices.com",
    phone: "+1 234-567-8905",
    company: "Cloud Services Ltd",
    status: "Active" as const,
    ticketCount: 3,
  },
];

export default function Customers() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Customers</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your customer database
          </p>
        </div>
        <Button data-testid="button-add-customer">
          <Plus className="h-4 w-4 mr-2" />
          Add Customer
        </Button>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search customers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-customers"
          />
        </div>
      </div>

      <CustomerTable customers={mockCustomers} testId="customer-table" />
    </div>
  );
}
