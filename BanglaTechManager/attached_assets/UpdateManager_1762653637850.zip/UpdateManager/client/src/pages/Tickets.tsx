import { useState } from "react";
import { TicketCard } from "@/components/TicketCard";
import { CreateTicketModal } from "@/components/CreateTicketModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Filter } from "lucide-react";

//todo: remove mock functionality
const mockTickets = [
  {
    id: "TKT-2401",
    title: "Cannot access dashboard",
    description: "Users report 404 error when accessing the main dashboard page. This issue started after the latest deployment.",
    category: "Bug" as const,
    status: "Open" as const,
    priority: "High" as const,
    assignee: { name: "John Doe", initials: "JD" },
    createdAt: "30 minutes ago",
  },
  {
    id: "TKT-2402",
    title: "Add export to CSV feature",
    description: "Request to add CSV export functionality for customer data to enable offline analysis and reporting.",
    category: "Feature" as const,
    status: "In Progress" as const,
    priority: "Medium" as const,
    assignee: { name: "Sarah Smith", initials: "SS" },
    createdAt: "2 hours ago",
  },
  {
    id: "TKT-2403",
    title: "Slow page load times",
    description: "Performance issues reported on the analytics page. Pages taking 5+ seconds to load.",
    category: "Support" as const,
    status: "Open" as const,
    priority: "Medium" as const,
    createdAt: "4 hours ago",
  },
  {
    id: "TKT-2404",
    title: "Password reset not working",
    description: "Users not receiving password reset emails. Email service may need configuration.",
    category: "Bug" as const,
    status: "In Progress" as const,
    priority: "High" as const,
    assignee: { name: "Mike Johnson", initials: "MJ" },
    createdAt: "5 hours ago",
  },
  {
    id: "TKT-2405",
    title: "Mobile app integration",
    description: "Request for API endpoints to support mobile application integration.",
    category: "Feature" as const,
    status: "Open" as const,
    priority: "Low" as const,
    createdAt: "1 day ago",
  },
  {
    id: "TKT-2406",
    title: "Database backup completed",
    description: "Automated database backup completed successfully.",
    category: "Support" as const,
    status: "Closed" as const,
    priority: "Low" as const,
    assignee: { name: "System", initials: "SY" },
    createdAt: "2 days ago",
  },
];

export default function Tickets() {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [createModalOpen, setCreateModalOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Tickets</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage support tickets and requests
          </p>
        </div>
        <Button onClick={() => setCreateModalOpen(true)} data-testid="button-create-ticket">
          <Plus className="h-4 w-4 mr-2" />
          Create Ticket
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tickets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-tickets"
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40" data-testid="select-status-filter">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-40" data-testid="select-category-filter">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="support">Support</SelectItem>
              <SelectItem value="bug">Bug</SelectItem>
              <SelectItem value="feature">Feature</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {mockTickets.map((ticket) => (
          <TicketCard key={ticket.id} {...ticket} testId={`ticket-${ticket.id}`} />
        ))}
      </div>

      <CreateTicketModal
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
        testId="create-ticket-modal"
      />
    </div>
  );
}
