import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, Search, MoreHorizontal, Mail } from "lucide-react";

//todo: remove mock functionality
const mockUsers = [
  {
    id: "1",
    name: "John Doe",
    email: "john@acmecorp.com",
    role: "Tenant Admin",
    status: "Active" as const,
    lastActive: "2 hours ago",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah@acmecorp.com",
    role: "Support Agent",
    status: "Active" as const,
    lastActive: "5 minutes ago",
  },
  {
    id: "3",
    name: "Mike Williams",
    email: "mike@acmecorp.com",
    role: "Support Agent",
    status: "Active" as const,
    lastActive: "1 hour ago",
  },
  {
    id: "4",
    name: "Emma Davis",
    email: "emma@acmecorp.com",
    role: "Support Agent",
    status: "Inactive" as const,
    lastActive: "3 days ago",
  },
  {
    id: "5",
    name: "Robert Brown",
    email: "robert@acmecorp.com",
    role: "Customer",
    status: "Active" as const,
    lastActive: "30 minutes ago",
  },
];

const roleColors = {
  "Tenant Admin": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  "Support Agent": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  "Customer": "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300",
};

export default function Users() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Users</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage users and their roles
          </p>
        </div>
        <Button data-testid="button-add-user">
          <Plus className="h-4 w-4 mr-2" />
          Add User
        </Button>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-users"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockUsers.map((user) => (
          <Card
            key={user.id}
            className="p-6 hover-elevate"
            data-testid={`user-card-${user.id}`}
          >
            <div className="flex items-start justify-between mb-4">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {user.name.split(" ").map((n) => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    data-testid={`user-actions-${user.id}`}
                  >
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Edit User</DropdownMenuItem>
                  <DropdownMenuItem>Change Role</DropdownMenuItem>
                  <DropdownMenuItem>View Activity</DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive">
                    Deactivate User
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="space-y-3">
              <div>
                <h3 className="font-semibold text-lg" data-testid={`user-name-${user.id}`}>
                  {user.name}
                </h3>
                <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                  <Mail className="h-3 w-3" />
                  <span className="text-xs">{user.email}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={roleColors[user.role as keyof typeof roleColors]}>
                  {user.role}
                </Badge>
                <Badge
                  className={
                    user.status === "Active"
                      ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                      : "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300"
                  }
                >
                  {user.status}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                Last active: {user.lastActive}
              </p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
