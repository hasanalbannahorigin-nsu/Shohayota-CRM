import { useState } from "react";
import { ChatInterface } from "@/components/ChatInterface";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

//todo: remove mock functionality
const mockConversations = [
  {
    id: "1",
    customerName: "Alice Johnson",
    lastMessage: "Thanks for your help!",
    timestamp: "2 min ago",
    unread: 0,
    status: "active" as const,
  },
  {
    id: "2",
    customerName: "Bob Smith",
    lastMessage: "I'm still having issues...",
    timestamp: "10 min ago",
    unread: 2,
    status: "active" as const,
  },
  {
    id: "3",
    customerName: "Carol Williams",
    lastMessage: "When will this be fixed?",
    timestamp: "1 hour ago",
    unread: 1,
    status: "waiting" as const,
  },
  {
    id: "4",
    customerName: "David Brown",
    lastMessage: "Perfect, that works!",
    timestamp: "3 hours ago",
    unread: 0,
    status: "resolved" as const,
  },
];

//todo: remove mock functionality
const mockMessages = [
  {
    id: "1",
    sender: "customer" as const,
    content: "Hi, I'm having trouble logging into my account",
    timestamp: "10:30 AM",
    senderName: "Alice Johnson",
  },
  {
    id: "2",
    sender: "agent" as const,
    content: "Hello Alice! I'd be happy to help you with that. Can you tell me what error message you're seeing?",
    timestamp: "10:31 AM",
    senderName: "Support Agent",
  },
  {
    id: "3",
    sender: "customer" as const,
    content: "It says 'Invalid credentials' but I'm sure my password is correct",
    timestamp: "10:32 AM",
    senderName: "Alice Johnson",
  },
  {
    id: "4",
    sender: "agent" as const,
    content: "Let me check your account. Have you recently changed your password?",
    timestamp: "10:33 AM",
    senderName: "Support Agent",
  },
  {
    id: "5",
    sender: "customer" as const,
    content: "No, I haven't changed it in months",
    timestamp: "10:34 AM",
    senderName: "Alice Johnson",
  },
  {
    id: "6",
    sender: "agent" as const,
    content: "I see the issue. I'll reset your password and send you a reset link via email. Please check your inbox in a few minutes.",
    timestamp: "10:35 AM",
    senderName: "Support Agent",
  },
  {
    id: "7",
    sender: "customer" as const,
    content: "Thanks for your help!",
    timestamp: "10:40 AM",
    senderName: "Alice Johnson",
  },
];

export default function Chat() {
  const [selectedConversation, setSelectedConversation] = useState("1");
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Chat</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Real-time customer communication
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        <Card className="flex flex-col">
          <div className="p-4 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-conversations"
              />
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2">
              {mockConversations.map((conversation) => (
                <button
                  key={conversation.id}
                  onClick={() => setSelectedConversation(conversation.id)}
                  className={`w-full p-3 rounded-md text-left hover-elevate active-elevate-2 ${
                    selectedConversation === conversation.id ? "bg-accent" : ""
                  }`}
                  data-testid={`conversation-${conversation.id}`}
                >
                  <div className="flex items-start gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {conversation.customerName.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-sm truncate">
                          {conversation.customerName}
                        </span>
                        {conversation.unread > 0 && (
                          <Badge className="bg-primary text-primary-foreground">
                            {conversation.unread}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {conversation.lastMessage}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {conversation.timestamp}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        </Card>

        <div className="lg:col-span-2">
          <ChatInterface
            messages={mockMessages}
            customerName="Alice Johnson"
            testId="chat-interface"
          />
        </div>
      </div>
    </div>
  );
}
