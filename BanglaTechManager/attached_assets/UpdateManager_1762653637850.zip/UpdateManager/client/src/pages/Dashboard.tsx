import { Users, TicketIcon, MessageSquare, CheckCircle } from "lucide-react";
import { StatsCard } from "@/components/StatsCard";
import { TicketCard } from "@/components/TicketCard";
import { Card } from "@/components/ui/card";

//todo: remove mock functionality
const mockRecentTickets = [
  {
    id: "TKT-2401",
    title: "Cannot access dashboard",
    description: "Users report 404 error when accessing the main dashboard page",
    category: "Bug" as const,
    status: "Open" as const,
    priority: "High" as const,
    assignee: { name: "John Doe", initials: "JD" },
    createdAt: "30 minutes ago",
  },
  {
    id: "TKT-2402",
    title: "Add export to CSV feature",
    description: "Request to add CSV export functionality for customer data",
    category: "Feature" as const,
    status: "In Progress" as const,
    priority: "Medium" as const,
    assignee: { name: "Sarah Smith", initials: "SS" },
    createdAt: "2 hours ago",
  },
  {
    id: "TKT-2403",
    title: "Slow page load times",
    description: "Performance issues reported on the analytics page",
    category: "Support" as const,
    status: "Open" as const,
    priority: "Medium" as const,
    createdAt: "4 hours ago",
  },
];

//todo: remove mock functionality
const mockActivity = [
  { id: "1", text: "New customer Alice Johnson registered", time: "5 min ago" },
  { id: "2", text: "Ticket #TKT-2400 marked as resolved", time: "15 min ago" },
  { id: "3", text: "Bob Smith updated profile information", time: "1 hour ago" },
  { id: "4", text: "New ticket #TKT-2401 created", time: "2 hours ago" },
  { id: "5", text: "Sarah Williams sent a message", time: "3 hours ago" },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Overview of your CRM system
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Customers"
          value={1248}
          icon={Users}
          trend={{ value: 12, isPositive: true }}
          testId="stats-customers"
        />
        <StatsCard
          title="Open Tickets"
          value={45}
          icon={TicketIcon}
          trend={{ value: 8, isPositive: false }}
          testId="stats-open-tickets"
        />
        <StatsCard
          title="Active Chats"
          value={12}
          icon={MessageSquare}
          trend={{ value: 5, isPositive: true }}
          testId="stats-active-chats"
        />
        <StatsCard
          title="Resolved Today"
          value={28}
          icon={CheckCircle}
          trend={{ value: 15, isPositive: true }}
          testId="stats-resolved"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-xl font-semibold">Recent Tickets</h2>
          <div className="space-y-4">
            {mockRecentTickets.map((ticket) => (
              <TicketCard
                key={ticket.id}
                {...ticket}
                testId={`ticket-${ticket.id}`}
              />
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Activity Feed</h2>
          <Card className="p-4">
            <div className="space-y-4">
              {mockActivity.map((activity) => (
                <div
                  key={activity.id}
                  className="flex gap-3"
                  data-testid={`activity-${activity.id}`}
                >
                  <div className="h-2 w-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm">{activity.text}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
