import { Button } from "@/components/ui/button";
import { Building2, Users, TicketIcon, MessageSquare } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="h-8 w-8 text-primary" />
            <span className="text-xl font-semibold">Multi-Tenant CRM</span>
          </div>
          <Button asChild data-testid="button-login">
            <a href="/api/login">Log In</a>
          </Button>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-4xl w-full space-y-12">
          <div className="text-center space-y-4">
            <h1 className="text-5xl font-bold">
              Complete CRM Solution for Multiple Organizations
            </h1>
            <p className="text-xl text-muted-foreground">
              Manage customers, support tickets, and team communication all in one secure platform
            </p>
            <div className="pt-4">
              <Button size="lg" asChild data-testid="button-get-started">
                <a href="/api/login">Get Started</a>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center space-y-3">
              <div className="h-12 w-12 mx-auto rounded-md bg-primary/10 flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Customer Management</h3>
              <p className="text-sm text-muted-foreground">
                Track and manage all your customer relationships in one place
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="h-12 w-12 mx-auto rounded-md bg-primary/10 flex items-center justify-center">
                <TicketIcon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Ticket System</h3>
              <p className="text-sm text-muted-foreground">
                Handle support requests, bugs, and feature requests efficiently
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="h-12 w-12 mx-auto rounded-md bg-primary/10 flex items-center justify-center">
                <MessageSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Real-time Chat</h3>
              <p className="text-sm text-muted-foreground">
                Communicate instantly with customers and team members
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="h-12 w-12 mx-auto rounded-md bg-primary/10 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Multi-Tenant</h3>
              <p className="text-sm text-muted-foreground">
                Complete data isolation for multiple organizations on one platform
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t p-4">
        <div className="max-w-7xl mx-auto text-center text-sm text-muted-foreground">
          © 2025 Multi-Tenant CRM. Built for enterprise-scale customer management.
        </div>
      </footer>
    </div>
  );
}
