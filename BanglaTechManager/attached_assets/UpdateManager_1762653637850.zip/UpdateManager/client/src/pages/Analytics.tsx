import { Card } from "@/components/ui/card";
import { StatsCard } from "@/components/StatsCard";
import {
  TrendingUp,
  Users,
  TicketIcon,
  Clock,
  CheckCircle,
} from "lucide-react";

//todo: remove mock functionality
const ticketsByCategory = [
  { category: "Support Request", count: 45, percentage: 45 },
  { category: "Bug Report", count: 35, percentage: 35 },
  { category: "Feature Request", count: 20, percentage: 20 },
];

//todo: remove mock functionality
const ticketsByStatus = [
  { status: "Open", count: 35, color: "bg-yellow-500" },
  { status: "In Progress", count: 28, color: "bg-blue-500" },
  { status: "Closed", count: 87, color: "bg-green-500" },
];

//todo: remove mock functionality
const recentActivity = [
  { month: "Jan", tickets: 45, customers: 120 },
  { month: "Feb", tickets: 52, customers: 145 },
  { month: "Mar", tickets: 48, customers: 160 },
  { month: "Apr", tickets: 65, customers: 178 },
  { month: "May", tickets: 58, customers: 195 },
  { month: "Jun", tickets: 72, customers: 215 },
];

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold">Analytics</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Performance metrics and insights
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Avg Response Time"
          value="2.4h"
          icon={Clock}
          trend={{ value: 15, isPositive: true }}
          testId="stats-response-time"
        />
        <StatsCard
          title="Resolution Rate"
          value="87%"
          icon={CheckCircle}
          trend={{ value: 5, isPositive: true }}
          testId="stats-resolution-rate"
        />
        <StatsCard
          title="Customer Growth"
          value="+12%"
          icon={TrendingUp}
          trend={{ value: 8, isPositive: true }}
          testId="stats-growth"
        />
        <StatsCard
          title="Active Users"
          value={156}
          icon={Users}
          trend={{ value: 3, isPositive: true }}
          testId="stats-active-users"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Tickets by Category</h3>
          <div className="space-y-4">
            {ticketsByCategory.map((item) => (
              <div key={item.category} data-testid={`category-${item.category}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">{item.category}</span>
                  <span className="text-sm text-muted-foreground">
                    {item.count} ({item.percentage}%)
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Tickets by Status</h3>
          <div className="space-y-4">
            {ticketsByStatus.map((item) => (
              <div
                key={item.status}
                className="flex items-center justify-between"
                data-testid={`status-${item.status}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`h-3 w-3 rounded-full ${item.color}`} />
                  <span className="text-sm font-medium">{item.status}</span>
                </div>
                <span className="text-sm text-muted-foreground">{item.count}</span>
              </div>
            ))}
          </div>
          <div className="mt-6 pt-6 border-t">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold">Total Tickets</span>
              <span className="text-sm font-semibold">150</span>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Activity Trend</h3>
        <div className="h-64 flex items-end justify-between gap-4">
          {recentActivity.map((item, index) => (
            <div
              key={item.month}
              className="flex-1 flex flex-col items-center gap-2"
              data-testid={`month-${item.month}`}
            >
              <div className="w-full flex flex-col items-center gap-1">
                <div
                  className="w-full bg-primary rounded-t-md transition-all hover-elevate"
                  style={{ height: `${(item.tickets / 80) * 200}px` }}
                  title={`${item.tickets} tickets`}
                />
                <span className="text-xs font-medium text-muted-foreground">
                  {item.month}
                </span>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t">
          <div className="flex items-center gap-4 justify-center">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-sm bg-primary" />
              <span className="text-sm text-muted-foreground">Tickets Created</span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
