import { storage } from "./storage";

async function seed() {
  console.log("Starting database seed...");

  try {
    // Create default tenant
    const tenant = await storage.createTenant({
      name: "Acme Corporation",
      contactEmail: "admin@acmecorp.com",
    });
    console.log("✓ Created tenant:", tenant.name);

    // Create some sample customers
    const customers = [
      {
        name: "Alice Johnson",
        email: "alice@techsolutions.com",
        phone: "+1 234-567-8901",
        company: "Tech Solutions Inc",
        status: "Active" as const,
        tenantId: tenant.id,
      },
      {
        name: "Bob Smith",
        email: "bob@digitalventures.com",
        phone: "+1 234-567-8902",
        company: "Digital Ventures",
        status: "Active" as const,
        tenantId: tenant.id,
      },
      {
        name: "Carol Williams",
        email: "carol@innovationlabs.com",
        phone: "+1 234-567-8903",
        company: "Innovation Labs",
        status: "Inactive" as const,
        tenantId: tenant.id,
      },
      {
        name: "David Brown",
        email: "david@startupco.com",
        phone: "+1 234-567-8904",
        company: "StartUp Co",
        status: "Active" as const,
        tenantId: tenant.id,
      },
      {
        name: "Eva Martinez",
        email: "eva@cloudservices.com",
        phone: "+1 234-567-8905",
        company: "Cloud Services Ltd",
        status: "Active" as const,
        tenantId: tenant.id,
      },
    ];

    for (const customerData of customers) {
      await storage.createCustomer(customerData);
    }
    console.log(`✓ Created ${customers.length} customers`);

    console.log("✓ Database seeded successfully!");
    console.log("\nIMPORTANT: When you log in for the first time, you'll need to:");
    console.log("1. Run this SQL to assign yourself to the tenant:");
    console.log(`   UPDATE users SET tenant_id = ${tenant.id}, role = 'tenant_admin' WHERE id = 'YOUR_USER_ID';`);
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

seed()
  .then(() => {
    console.log("Seed completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Seed failed:", error);
    process.exit(1);
  });
