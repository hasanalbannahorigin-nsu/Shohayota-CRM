import {
  users,
  tenants,
  customers,
  tickets,
  messages,
  type User,
  type UpsertUser,
  type InsertUser,
  type Tenant,
  type InsertTenant,
  type Customer,
  type InsertCustomer,
  type Ticket,
  type InsertTicket,
  type Message,
  type InsertMessage,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsersByTenant(tenantId: number): Promise<User[]>;
  updateUserRole(userId: string, role: string, tenantId: number): Promise<User | undefined>;
  
  // Tenant operations
  getTenant(id: number): Promise<Tenant | undefined>;
  getAllTenants(): Promise<Tenant[]>;
  createTenant(tenant: InsertTenant): Promise<Tenant>;
  
  // Customer operations
  getCustomer(id: number, tenantId: number): Promise<Customer | undefined>;
  getCustomersByTenant(tenantId: number): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>, tenantId: number): Promise<Customer | undefined>;
  deleteCustomer(id: number, tenantId: number): Promise<boolean>;
  
  // Ticket operations
  getTicket(id: number, tenantId: number): Promise<Ticket | undefined>;
  getTicketsByTenant(tenantId: number): Promise<Ticket[]>;
  getTicketsByCustomer(customerId: number, tenantId: number): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: number, ticket: Partial<InsertTicket>, tenantId: number): Promise<Ticket | undefined>;
  assignTicket(ticketId: number, assignedToId: string, tenantId: number): Promise<Ticket | undefined>;
  
  // Message operations
  getMessagesByTicket(ticketId: number, tenantId: number): Promise<Message[]>;
  getMessagesByCustomer(customerId: number, tenantId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Analytics operations
  getTicketStats(tenantId: number): Promise<{
    total: number;
    open: number;
    inProgress: number;
    closed: number;
    byCategory: { category: string; count: number }[];
    byPriority: { priority: string; count: number }[];
  }>;
  getCustomerStats(tenantId: number): Promise<{
    total: number;
    active: number;
    inactive: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsersByTenant(tenantId: number): Promise<User[]> {
    return await db.select().from(users).where(eq(users.tenantId, tenantId));
  }

  async updateUserRole(userId: string, role: string, tenantId: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ role: role as any, updatedAt: new Date() })
      .where(and(eq(users.id, userId), eq(users.tenantId, tenantId)))
      .returning();
    return user;
  }

  // Tenant operations
  async getTenant(id: number): Promise<Tenant | undefined> {
    const [tenant] = await db.select().from(tenants).where(eq(tenants.id, id));
    return tenant;
  }

  async getAllTenants(): Promise<Tenant[]> {
    return await db.select().from(tenants);
  }

  async createTenant(tenantData: InsertTenant): Promise<Tenant> {
    const [tenant] = await db.insert(tenants).values(tenantData).returning();
    return tenant;
  }

  // Customer operations
  async getCustomer(id: number, tenantId: number): Promise<Customer | undefined> {
    const [customer] = await db
      .select()
      .from(customers)
      .where(and(eq(customers.id, id), eq(customers.tenantId, tenantId)));
    return customer;
  }

  async getCustomersByTenant(tenantId: number): Promise<Customer[]> {
    return await db
      .select()
      .from(customers)
      .where(eq(customers.tenantId, tenantId))
      .orderBy(desc(customers.createdAt));
  }

  async createCustomer(customerData: InsertCustomer): Promise<Customer> {
    const [customer] = await db.insert(customers).values(customerData).returning();
    return customer;
  }

  async updateCustomer(
    id: number,
    customerData: Partial<InsertCustomer>,
    tenantId: number
  ): Promise<Customer | undefined> {
    const [customer] = await db
      .update(customers)
      .set(customerData)
      .where(and(eq(customers.id, id), eq(customers.tenantId, tenantId)))
      .returning();
    return customer;
  }

  async deleteCustomer(id: number, tenantId: number): Promise<boolean> {
    const result = await db
      .delete(customers)
      .where(and(eq(customers.id, id), eq(customers.tenantId, tenantId)));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Ticket operations
  async getTicket(id: number, tenantId: number): Promise<Ticket | undefined> {
    const [ticket] = await db
      .select()
      .from(tickets)
      .where(and(eq(tickets.id, id), eq(tickets.tenantId, tenantId)));
    return ticket;
  }

  async getTicketsByTenant(tenantId: number): Promise<Ticket[]> {
    return await db
      .select()
      .from(tickets)
      .where(eq(tickets.tenantId, tenantId))
      .orderBy(desc(tickets.createdAt));
  }

  async getTicketsByCustomer(customerId: number, tenantId: number): Promise<Ticket[]> {
    return await db
      .select()
      .from(tickets)
      .where(and(eq(tickets.customerId, customerId), eq(tickets.tenantId, tenantId)))
      .orderBy(desc(tickets.createdAt));
  }

  async createTicket(ticketData: InsertTicket): Promise<Ticket> {
    // Generate ticket number
    const count = await db
      .select({ count: sql<number>`count(*)` })
      .from(tickets)
      .where(eq(tickets.tenantId, ticketData.tenantId));
    
    const ticketNumber = `TKT-${String((count[0]?.count || 0) + 1).padStart(4, "0")}`;
    
    const [ticket] = await db
      .insert(tickets)
      .values({ ...ticketData, ticketNumber })
      .returning();
    return ticket;
  }

  async updateTicket(
    id: number,
    ticketData: Partial<InsertTicket>,
    tenantId: number
  ): Promise<Ticket | undefined> {
    const [ticket] = await db
      .update(tickets)
      .set({ ...ticketData, updatedAt: new Date() })
      .where(and(eq(tickets.id, id), eq(tickets.tenantId, tenantId)))
      .returning();
    return ticket;
  }

  async assignTicket(
    ticketId: number,
    assignedToId: string,
    tenantId: number
  ): Promise<Ticket | undefined> {
    const [ticket] = await db
      .update(tickets)
      .set({ assignedToId, updatedAt: new Date() })
      .where(and(eq(tickets.id, ticketId), eq(tickets.tenantId, tenantId)))
      .returning();
    return ticket;
  }

  // Message operations
  async getMessagesByTicket(ticketId: number, tenantId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(and(eq(messages.ticketId, ticketId), eq(messages.tenantId, tenantId)))
      .orderBy(messages.createdAt);
  }

  async getMessagesByCustomer(customerId: number, tenantId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(and(eq(messages.customerId, customerId), eq(messages.tenantId, tenantId)))
      .orderBy(desc(messages.createdAt));
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(messageData).returning();
    return message;
  }

  // Analytics operations
  async getTicketStats(tenantId: number) {
    const allTickets = await db
      .select()
      .from(tickets)
      .where(eq(tickets.tenantId, tenantId));

    const total = allTickets.length;
    const open = allTickets.filter((t) => t.status === "Open").length;
    const inProgress = allTickets.filter((t) => t.status === "In Progress").length;
    const closed = allTickets.filter((t) => t.status === "Closed").length;

    const byCategory = [
      {
        category: "Support",
        count: allTickets.filter((t) => t.category === "Support").length,
      },
      {
        category: "Bug",
        count: allTickets.filter((t) => t.category === "Bug").length,
      },
      {
        category: "Feature",
        count: allTickets.filter((t) => t.category === "Feature").length,
      },
    ];

    const byPriority = [
      {
        priority: "Low",
        count: allTickets.filter((t) => t.priority === "Low").length,
      },
      {
        priority: "Medium",
        count: allTickets.filter((t) => t.priority === "Medium").length,
      },
      {
        priority: "High",
        count: allTickets.filter((t) => t.priority === "High").length,
      },
    ];

    return { total, open, inProgress, closed, byCategory, byPriority };
  }

  async getCustomerStats(tenantId: number) {
    const allCustomers = await db
      .select()
      .from(customers)
      .where(eq(customers.tenantId, tenantId));

    return {
      total: allCustomers.length,
      active: allCustomers.filter((c) => c.status === "Active").length,
      inactive: allCustomers.filter((c) => c.status === "Inactive").length,
    };
  }
}

export const storage = new DatabaseStorage();
