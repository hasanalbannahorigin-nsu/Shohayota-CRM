import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, getTenantFromRequest } from "./replitAuth";
import { WebSocketServer, WebSocket } from "ws";
import {
  insertCustomerSchema,
  insertTicketSchema,
  insertMessageSchema,
  insertTenantSchema,
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Auth route - get current user
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Tenant routes
  app.get("/api/tenants", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      
      // Only super admins can see all tenants
      if (user?.role === "super_admin") {
        const tenants = await storage.getAllTenants();
        res.json(tenants);
      } else if (user?.tenantId) {
        const tenant = await storage.getTenant(user.tenantId);
        res.json([tenant]);
      } else {
        res.json([]);
      }
    } catch (error) {
      console.error("Error fetching tenants:", error);
      res.status(500).json({ message: "Failed to fetch tenants" });
    }
  });

  app.post("/api/tenants", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      
      // Only super admins can create tenants
      if (user?.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const parsed = insertTenantSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const tenant = await storage.createTenant(parsed.data);
      res.json(tenant);
    } catch (error) {
      console.error("Error creating tenant:", error);
      res.status(500).json({ message: "Failed to create tenant" });
    }
  });

  // Customer routes
  app.get("/api/customers", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const customers = await storage.getCustomersByTenant(tenantId);
      res.json(customers);
    } catch (error) {
      console.error("Error fetching customers:", error);
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  app.post("/api/customers", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const tenantId = await getTenantFromRequest(req);
      
      if (!tenantId || !user) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      // Only tenant admins and support agents can create customers
      if (user.role !== "tenant_admin" && user.role !== "support_agent" && user.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const parsed = insertCustomerSchema.safeParse({ ...req.body, tenantId });
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const customer = await storage.createCustomer(parsed.data);
      res.json(customer);
    } catch (error) {
      console.error("Error creating customer:", error);
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  app.patch("/api/customers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const tenantId = await getTenantFromRequest(req);
      
      if (!tenantId || !user) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      // Only tenant admins and support agents can update customers
      if (user.role !== "tenant_admin" && user.role !== "support_agent" && user.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { updateCustomerSchema } = await import("@shared/schema");
      const parsed = updateCustomerSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const customer = await storage.updateCustomer(
        parseInt(req.params.id),
        parsed.data,
        tenantId
      );
      res.json(customer);
    } catch (error) {
      console.error("Error updating customer:", error);
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const tenantId = await getTenantFromRequest(req);
      
      if (!tenantId || !user) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      // Only tenant admins can delete customers
      if (user.role !== "tenant_admin" && user.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const success = await storage.deleteCustomer(parseInt(req.params.id), tenantId);
      res.json({ success });
    } catch (error) {
      console.error("Error deleting customer:", error);
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // Ticket routes
  app.get("/api/tickets", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const tickets = await storage.getTicketsByTenant(tenantId);
      res.json(tickets);
    } catch (error) {
      console.error("Error fetching tickets:", error);
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });

  app.post("/api/tickets", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const userId = req.user.claims.sub;
      const parsed = insertTicketSchema.safeParse({
        ...req.body,
        tenantId,
        createdById: userId,
      });

      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const ticket = await storage.createTicket(parsed.data);
      res.json(ticket);
    } catch (error) {
      console.error("Error creating ticket:", error);
      res.status(500).json({ message: "Failed to create ticket" });
    }
  });

  app.patch("/api/tickets/:id", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const tenantId = await getTenantFromRequest(req);
      
      if (!tenantId || !user) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      // Only tenant admins and support agents can update tickets
      if (user.role !== "tenant_admin" && user.role !== "support_agent" && user.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { updateTicketSchema } = await import("@shared/schema");
      const parsed = updateTicketSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const ticket = await storage.updateTicket(
        parseInt(req.params.id),
        parsed.data,
        tenantId
      );
      res.json(ticket);
    } catch (error) {
      console.error("Error updating ticket:", error);
      res.status(500).json({ message: "Failed to update ticket" });
    }
  });

  app.post("/api/tickets/:id/assign", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      const tenantId = await getTenantFromRequest(req);
      
      if (!tenantId || !user) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      // Only tenant admins and support agents can assign tickets
      if (user.role !== "tenant_admin" && user.role !== "support_agent" && user.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const parsed = z.object({ assignedToId: z.string() }).safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const ticket = await storage.assignTicket(
        parseInt(req.params.id),
        parsed.data.assignedToId,
        tenantId
      );
      res.json(ticket);
    } catch (error) {
      console.error("Error assigning ticket:", error);
      res.status(500).json({ message: "Failed to assign ticket" });
    }
  });

  // Message routes
  app.get("/api/tickets/:id/messages", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const messages = await storage.getMessagesByTicket(
        parseInt(req.params.id),
        tenantId
      );
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const userId = req.user.claims.sub;
      const parsed = insertMessageSchema.safeParse({
        ...req.body,
        tenantId,
        senderId: userId,
      });

      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error });
      }

      const message = await storage.createMessage(parsed.data);
      
      // Broadcast to WebSocket clients if available
      if (wss) {
        const messageData = JSON.stringify({ type: "new_message", data: message });
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(messageData);
          }
        });
      }

      res.json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/tickets", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const stats = await storage.getTicketStats(tenantId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching ticket stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/analytics/customers", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const stats = await storage.getCustomerStats(tenantId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching customer stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // User management routes
  app.get("/api/users", isAuthenticated, async (req: any, res) => {
    try {
      const tenantId = await getTenantFromRequest(req);
      if (!tenantId) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      const users = await storage.getUsersByTenant(tenantId);
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch("/api/users/:id/role", isAuthenticated, async (req: any, res) => {
    try {
      const currentUser = await storage.getUser(req.user.claims.sub);
      const tenantId = await getTenantFromRequest(req);
      
      if (!tenantId || !currentUser) {
        return res.status(403).json({ message: "No tenant assigned" });
      }

      // Only tenant admins can change roles
      if (currentUser.role !== "tenant_admin" && currentUser.role !== "super_admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { role } = req.body;
      const user = await storage.updateUserRole(req.params.id, role, tenantId);
      res.json(user);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  const httpServer = createServer(app);

  // Setup WebSocket for real-time chat on separate path to avoid conflicts with Vite
  let wss: WebSocketServer | null = null;
  try {
    wss = new WebSocketServer({ server: httpServer, path: '/ws' });
    
    wss.on("connection", (ws) => {
      console.log("Client connected to WebSocket");

      ws.on("message", (data) => {
        // Broadcast message to all clients
        wss?.clients.forEach((client) => {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(data.toString());
          }
        });
      });

      ws.on("close", () => {
        console.log("Client disconnected from WebSocket");
      });
    });
  } catch (error) {
    console.error("Failed to setup WebSocket:", error);
  }

  return httpServer;
}
